package com.lucky.core.service.impl;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lucky.core.dto.LoginDTO;
import com.lucky.core.dto.RefreshResult;
import com.lucky.core.dto.RegisterDTO;
import com.lucky.core.dto.TokenDTO;
import com.lucky.core.entity.User;
import com.lucky.core.entity.UserInfo;
import com.lucky.core.entity.UserPhone;
import com.lucky.core.entity.UserRole;
import com.lucky.core.mapper.UserInfoMapper;
import com.lucky.core.mapper.UserMapper;
import com.lucky.core.mapper.UserPhoneMapper;
import com.lucky.core.mapper.UserRoleMapper;
import com.lucky.core.service.TokenIssuer;
import com.lucky.core.service.TokenRedisService;
import com.lucky.core.service.UserService;
import com.lucky.core.utils.JwtUtil;
import com.lucky.exception.BusinessException;
import com.lucky.exception.UnauthorizedException;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    /** 默认角色：普通用户(tb_role.id) */
    private static final Long DEFAULT_ROLE_ID = 1L;

    /** 并发轮换时，落败方等待抢占者写入新 jti 的最长时间(毫秒) */
    private static final long ROTATION_WAIT_MILLIS = 500;

    /** 等待轮换结果的轮询间隔(毫秒) */
    private static final long ROTATION_POLL_MILLIS = 20;

    @Resource
    private JwtUtil jwtUtil;

    @Resource
    private TokenIssuer tokenIssuer;

    @Resource
    private PasswordEncoder passwordEncoder;

    @Resource
    private TokenRedisService tokenRedisService;

    @Resource
    private UserInfoMapper userInfoMapper;

    @Resource
    private UserPhoneMapper userPhoneMapper;

    @Resource
    private UserRoleMapper userRoleMapper;

    @Override
    // 注册跨 4 张表，加事务保证要么全成功、要么全回滚
    @Transactional(rollbackFor = Exception.class)
    public void register(RegisterDTO registerDTO) {
        // 1. 先查手机号是否已存在(拦掉绝大多数重复提交)
        boolean exists = lambdaQuery().eq(User::getPhone, registerDTO.getPhone()).exists();
        if (exists) {
            throw new BusinessException("该手机号已注册");
        }
        // 2. 密码以 Bcrypt 加密存储；昵称默认使用用户id（先取雪花id再落库）
        Long id = IdWorker.getId();
        User user = new User();
        user.setId(id);
        user.setPhone(registerDTO.getPhone());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setNickName(String.valueOf(id));
        // 并发兜底：万一两个请求同时通过了上面的查重，靠 tb_user.phone 唯一索引拦下第二个
        try {
            save(user);
        } catch (DuplicateKeyException e) {
            throw new BusinessException("该手机号已注册");
        }

        // 3. 用户扩展信息：粉丝数/关注数初始为 0
        UserInfo userInfo = new UserInfo();
        userInfo.setId(IdWorker.getId());
        userInfo.setUserId(id);
        userInfo.setFans(0);
        userInfo.setFollowee(0);
        userInfoMapper.insert(userInfo);

        // 4. 手机号记录
        UserPhone userPhone = new UserPhone();
        userPhone.setId(IdWorker.getId());
        userPhone.setUserId(id);
        userPhone.setPhone(registerDTO.getPhone());
        userPhoneMapper.insert(userPhone);

        // 5. 默认绑定普通用户角色(tb_role.role_code = USER, id = 1)
        UserRole userRole = new UserRole();
        userRole.setId(IdWorker.getId());
        userRole.setUserId(id);
        userRole.setRoleId(DEFAULT_ROLE_ID);
        userRoleMapper.insert(userRole);
    }

    @Override
    public TokenDTO login(LoginDTO loginDTO) {
        // 1. 按手机号查用户
        User user = lambdaQuery().eq(User::getPhone, loginDTO.getPhone()).one();
        // 账号不存在与密码错误统一提示，避免暴露用户是否存在
        // 密码以 Bcrypt 存储，用 matches 比对
        if (user == null || user.getPassword() == null
                || !passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            throw new BusinessException("账号或密码错误");
        }
        // 2. 签发双 Token 并登记会话状态(短 token 返回前端，长 token 由 Controller 写 Cookie)
        return tokenIssuer.issuePair(user.getId()).tokens();
    }

    @Override
    public RefreshResult refreshAccessToken(String refreshToken) {
        // 1. 校验 refresh token：签名/类型/时效任一不过即视为未登录
        JwtUtil.Payload payload = jwtUtil.parse(refreshToken, JwtUtil.TYPE_REFRESH);
        if (payload == null) {
            throw new UnauthorizedException("登录已过期，请重新登录");
        }

        // 2. 当前会话 → 抢占轮换权。并发请求都会先通过上面/这里的校验，
        //    没有抢占就会各自轮换出两个会话
        if (tokenRedisService.isRefreshSessionValid(payload.userId(), payload.jti())) {
            long grace = jwtUtil.getRefreshGraceSeconds();
            if (tokenRedisService.tryClaimRotation(payload.jti(), grace)) {
                // 2a. 抢到了：先登记新会话、再删旧会话(顺序不可反，否则中间存在「零有效会话」窗口)
                JwtUtil.IssuedTokens issued = tokenIssuer.issuePair(payload.userId());
                tokenRedisService.removeRefreshSession(payload.userId(), payload.jti());
                // 把结果写给并发方，让它们能复用同一个新会话
                tokenRedisService.completeRotation(payload.jti(), issued.refreshJti(), grace);
                return new RefreshResult(issued.tokens().getAccessToken(), issued.tokens().getRefreshToken());
            }
            // 2b. 没抢到：已有请求在轮换，等它写好结果后复用同一会话
            String newJti = awaitRotation(payload.jti());
            if (newJti != null && tokenRedisService.isRefreshSessionValid(payload.userId(), newJti)) {
                return new RefreshResult(tokenIssuer.issueAccessOnly(payload.userId()), null);
            }
            throw new BusinessException("刷新繁忙，请稍后重试");
        }

        // 3. 非当前会话：可能是刚被轮换(宽限窗口内)，也可能是重放
        String rotated = awaitRotation(payload.jti());
        if (rotated != null && tokenRedisService.isRefreshSessionValid(payload.userId(), rotated)) {
            // 良性重复：新会话还活着，说明不是盗用，只补一个 access
            // (只发 access 不发 refresh：即便真是重放，攻击者也拿不到可链式续期的凭证)
            log.warn("refresh 在宽限窗口内被重复使用，userId={}, jti={}", payload.userId(), payload.jti());
            return new RefreshResult(tokenIssuer.issueAccessOnly(payload.userId()), null);
        }

        // 4. 到此无法区分「盗用 / 客户端崩溃 / 响应丢了 / Redis 抖动」。
        //    不做破坏性 kickOut：那会把用户所有设备一起登出，丢响应(移动网络常态)时就是自伤式 DoS。
        //    只拒绝这一次请求，并留下日志供排查/风控。
        log.warn("refresh 复用疑似盗用，userId={}, jti={}", payload.userId(), payload.jti());
        throw new UnauthorizedException("登录状态异常，请重新登录");
    }

    @Override
    public void logout(String accessToken, String refreshToken) {
        // access / refresh 任一能解析出身份即可定位用户；两者都失效则无可清理(调用方清 Cookie 即可)
        JwtUtil.Payload access = jwtUtil.parse(accessToken, JwtUtil.TYPE_ACCESS);
        JwtUtil.Payload refresh = jwtUtil.parse(refreshToken, JwtUtil.TYPE_REFRESH);
        Long userId = access != null ? access.userId()
                : (refresh != null ? refresh.userId() : null);
        if (userId != null) {
            tokenRedisService.kickOut(userId);
        }
    }

    @Override
    public void kickOut(Long userId) {
        // 踢下线(封号/改密等场景)：access 白名单 + refresh 会话一并清空，两者都即时生效
        tokenRedisService.kickOut(userId);
    }

    /**
     * 读取某个旧 jti 的轮换结果；若抢占者还在轮换中(哨兵值)则短暂轮询等待
     * <p>记录不存在时立即返回 null 不等待——那是「确实没有轮换过」，不是等待中的状态
     *
     * @return 新会话的 jti；无记录或等待超时返回 null
     */
    private String awaitRotation(String oldJti) {
        long deadline = System.currentTimeMillis() + ROTATION_WAIT_MILLIS;
        while (true) {
            String value = tokenRedisService.getRotation(oldJti);
            if (!TokenRedisService.ROTATION_PENDING.equals(value)) {
                return value;
            }
            if (System.currentTimeMillis() >= deadline) {
                return null;
            }
            try {
                Thread.sleep(ROTATION_POLL_MILLIS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            }
        }
    }
}
